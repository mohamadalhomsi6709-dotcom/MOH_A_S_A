// ===== PARTICLES =====
(function(){
  const canvas = document.getElementById('particles-canvas');
  const ctx = canvas.getContext('2d');
  let W, H, particles = [];

  function resize(){
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function rand(a,b){return Math.random()*(b-a)+a;}

  for(let i=0;i<70;i++){
    particles.push({
      x:rand(0,window.innerWidth),
      y:rand(0,window.innerHeight),
      r:rand(0.3,1.8),
      vx:rand(-0.15,0.15),
      vy:rand(-0.25,-0.05),
      alpha:rand(0.1,0.5),
      flicker:rand(0,Math.PI*2)
    });
  }

  function draw(){
    ctx.clearRect(0,0,W,H);
    particles.forEach(p=>{
      p.flicker+=0.02;
      const a = p.alpha*(0.7+0.3*Math.sin(p.flicker));
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(212,160,23,${a})`;
      ctx.fill();
      p.x+=p.vx; p.y+=p.vy;
      if(p.y<-5){p.y=H+5; p.x=rand(0,W);}
      if(p.x<0)p.x=W; if(p.x>W)p.x=0;
    });
    requestAnimationFrame(draw);
  }
  draw();
})();

// ===== DATA =====
const EXAM_DATE = new Date(2026,5,25);
let tasks = JSON.parse(localStorage.getItem('hd_tasks_v3')||'[]');
let stats = JSON.parse(localStorage.getItem('hd_stats_v3')||'{"sessions":0,"mins":0,"date":""}');
let streak = parseInt(localStorage.getItem('hd_streak_v3')||'0');
const today = new Date().toDateString();
if(stats.date!==today){
  if(stats.date===new Date(Date.now()-86400000).toDateString()){streak++;}
  else if(stats.date!==today){streak=1;}
  stats={sessions:0,mins:0,date:today};
  localStorage.setItem('hd_stats_v3',JSON.stringify(stats));
  localStorage.setItem('hd_streak_v3',streak);
}

// ===== QUOTES =====
const quotes=[
  "النجاح ليس نهائياً، والفشل ليس قاتلاً، ما يهم هو الشجاعة على الاستمرار.",
  "العلم لا يُكتسب بالراحة، بل بركوب الصعاب والصبر عليها.",
  "الفائزون لا يفعلون أشياء مختلفة، بل يفعلون الأشياء بشكل مختلف.",
  "كل دقيقة تمضيها في التخطيط توفر عليك عشر دقائق في التنفيذ.",
  "النجاح هو مجموع جهود صغيرة متكررة يوماً بعد يوم.",
  "لا تقارن نفسك بالآخرين، قارنها بمن كنت عليه بالأمس.",
  "الدراسة اليوم تصنع الحرية غداً.",
  "المعدل العالي لا يُبنى في ليلة واحدة، بل بالثبات كل يوم.",
  "العقل الذي يسعى للتعلم لا يمكن لأحد أن يوقفه.",
  "ابدأ من حيث أنت، استخدم ما لديك، افعل ما تستطيع.",
  "الطموح بلا عمل وهم، والعمل بلا طموح تعب.",
  "كن الشخص الذي كان طفلك يحلم بأن يصبح.",
];
let qIdx=Math.floor(Math.random()*quotes.length);
function newQuote(){
  qIdx=(qIdx+1)%quotes.length;
  const el=document.getElementById('quoteText');
  el.style.opacity=0;el.style.transform='translateY(8px)';
  el.style.transition='opacity 0.35s,transform 0.35s';
  setTimeout(()=>{
    el.textContent=quotes[qIdx];
    el.style.opacity=1;el.style.transform='translateY(0)';
  },300);
}

// ===== CLOCK =====
function updateClock(){
  const now=new Date();
  document.getElementById('clock').textContent=now.toLocaleTimeString('en-US',{hour12:false});
  document.getElementById('dateText').textContent=now.toLocaleDateString('ar-SA',{weekday:'long',day:'numeric',month:'long'});
  const h=now.getHours();
  let g="🌙 السهر يصنع المعدلات يا محمد";
  if(h>=5&&h<12)g="🌅 صباح الهمة والفرم يا محمد";
  else if(h>=12&&h<17)g="⚡ طاقة منتصف اليوم.. استمر يا حمصي";
  else if(h>=17&&h<21)g="☕ مساء التركيز والروقان يا غالي";
  document.getElementById('greeting').textContent=g;
  const diff=EXAM_DATE-now;
  if(diff>0){
    const days=Math.floor(diff/86400000);
    const hours=Math.floor((diff%86400000)/3600000);
    const mins=Math.floor((diff%3600000)/60000);
    document.getElementById('examTimer').textContent=`${days} يوم و ${hours} ساعة و ${mins} دقيقة`;
  }else{
    document.getElementById('examTimer').textContent='🔥 معركة الوزاري بدأت!';
  }
}
setInterval(updateClock,1000);updateClock();

// ===== STATS =====
function updateStats(){
  document.getElementById('statSessions').textContent=stats.sessions;
  document.getElementById('statDone').textContent=tasks.filter(t=>t.sessions>=t.target).length;
  document.getElementById('statMins').textContent=stats.mins;
  document.getElementById('statStreak').textContent=streak;
}
updateStats();

// ===== TASKS =====
function getEmoji(t){
  const l=t.toLowerCase();
  if(l.includes('رياضيات'))return'📐 ';
  if(l.includes('فيزياء'))return'⚗️ ';
  if(l.includes('كيمياء'))return'🧪 ';
  if(l.includes('أحياء')||l.includes('احياء'))return'🧬 ';
  if(l.includes('مالية')||l.includes('محاسبة'))return'💰 ';
  if(l.includes('دين')||l.includes('إسلامية'))return'🕌 ';
  if(l.includes('إنجليزي')||l.includes('انجليزي'))return'🇬🇧 ';
  if(l.includes('عربي'))return'📖 ';
  if(l.includes('تاريخ'))return'🏛️ ';
  return'⚡ ';
}
function renderTasks(){
  const list=document.getElementById('taskList');list.innerHTML='';
  tasks.forEach((t,i)=>{
    const done=t.sessions>=t.target;
    const div=document.createElement('div');
    div.className='task-item'+(done?' done':'');
    div.innerHTML=`
      <span class="task-name">${t.text}${done?' 🏆':''}</span>
      <div class="sess-ctrl">
        <button class="sess-btn" onclick="chSess(${i},-1)">−</button>
        <span class="sess-num">${t.sessions}/${t.target}</span>
        <button class="sess-btn" onclick="chSess(${i},1)">+</button>
      </div>
      <i class="fas fa-trash-can del-btn" onclick="delTask(${i})"></i>
    `;
    list.appendChild(div);
  });
  updateStats();
}
function addTask(){
  const txt=document.getElementById('taskIn').value.trim();if(!txt)return;
  const target=parseInt(document.getElementById('taskSess').value)||3;
  tasks.push({text:getEmoji(txt)+txt,sessions:0,target});
  localStorage.setItem('hd_tasks_v3',JSON.stringify(tasks));
  document.getElementById('taskIn').value='';
  renderTasks();toast('✦ تمت إضافة المهمة!');
}
function chSess(i,d){
  tasks[i].sessions=Math.max(0,Math.min(tasks[i].target,tasks[i].sessions+d));
  if(d>0){stats.sessions++;stats.mins+=25;localStorage.setItem('hd_stats_v3',JSON.stringify(stats));}
  localStorage.setItem('hd_tasks_v3',JSON.stringify(tasks));
  renderTasks();
  if(tasks[i].sessions>=tasks[i].target&&d>0)toast(`👑 كفو! أنجزت كامل جلسات: ${tasks[i].text.substring(3)}`);
}
function delTask(i){tasks.splice(i,1);localStorage.setItem('hd_tasks_v3',JSON.stringify(tasks));renderTasks();}
document.getElementById('taskIn').addEventListener('keypress',e=>{if(e.key==='Enter')addTask();});
renderTasks();

// ===== NOTES =====
const notesArea=document.getElementById('notesArea');
notesArea.value=localStorage.getItem('hd_notes_v3')||'';
let notesTimer;
notesArea.addEventListener('input',()=>{
  clearTimeout(notesTimer);
  notesTimer=setTimeout(()=>{
    localStorage.setItem('hd_notes_v3',notesArea.value);
    const s=document.getElementById('notesSaved');
    s.classList.add('show');setTimeout(()=>s.classList.remove('show'),2000);
  },800);
});

// ===== POMO =====
let pomoInt,pomoRunning=false,pomoLeft=0,pomoTotal=0;
let studyMin=25,breakMin=5,isBreak=false;
function launchPomo(s,b){
  studyMin=s;breakMin=b;pomoTotal=s*60;pomoLeft=pomoTotal;
  isBreak=false;pomoRunning=false;
  document.getElementById('pomoStateText').textContent='جلسة التركيز الملكية 🎯';
  document.getElementById('pomoToggleBtn').innerHTML='<i class="fas fa-play"></i> تشغيل';
  updatePomoDisplay();
  document.getElementById('pomoOverlay').style.display='flex';
  if(!document.fullscreenElement)document.documentElement.requestFullscreen().catch(()=>{});
}
function updatePomoDisplay(){
  const m=Math.floor(pomoLeft/60),s=pomoLeft%60;
  document.getElementById('pomoCounter').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  document.getElementById('pomoBar').style.width=`${(pomoLeft/pomoTotal)*100}%`;
}
function togglePomo(){
  const btn=document.getElementById('pomoToggleBtn');
  if(pomoRunning){clearInterval(pomoInt);pomoRunning=false;btn.innerHTML='<i class="fas fa-play"></i> تشغيل';}
  else{
    pomoRunning=true;btn.innerHTML='<i class="fas fa-pause"></i> إيقاف';
    pomoInt=setInterval(()=>{
      if(pomoLeft<=0){
        clearInterval(pomoInt);pomoRunning=false;btn.innerHTML='<i class="fas fa-play"></i> تشغيل';
        if(!isBreak){
          stats.sessions++;stats.mins+=studyMin;
          localStorage.setItem('hd_stats_v3',JSON.stringify(stats));updateStats();
          isBreak=true;pomoTotal=breakMin*60;pomoLeft=pomoTotal;
          document.getElementById('pomoStateText').textContent='وقت الراحة الملكية ☕';
          alert(`👑 بطل يا محمد! انتهت جلسة الفوكس، ريّح الآن ${breakMin} دقائق.`);
        }else{
          isBreak=false;pomoTotal=studyMin*60;pomoLeft=pomoTotal;
          document.getElementById('pomoStateText').textContent='جلسة التركيز الملكية 🎯';
          alert('⚡ انتهى البريك! يلا يا حمصي نرجع للفرم والهمة.');
        }
        updatePomoDisplay();return;
      }
      pomoLeft--;updatePomoDisplay();
    },1000);
  }
}
function exitPomo(){
  clearInterval(pomoInt);pomoRunning=false;
  document.getElementById('pomoOverlay').style.display='none';
  if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});
}

// ===== SPARK =====
let sparkInt,sparkRunning=false,sparkSec=600;
function toggleSpark(){
  const btn=document.getElementById('sparkBtn'),disp=document.getElementById('sparkTimer');
  if(sparkRunning){clearInterval(sparkInt);sparkRunning=false;btn.innerHTML='<i class="fas fa-fire"></i> استئناف التحدي';}
  else{
    sparkRunning=true;disp.style.display='block';btn.innerHTML='<i class="fas fa-pause"></i> إيقاف مؤقت';
    sparkInt=setInterval(()=>{
      if(sparkSec<=0){
        clearInterval(sparkInt);sparkRunning=false;disp.style.display='none';sparkSec=600;
        btn.innerHTML='<i class="fas fa-fire"></i> تحدي الـ 10 دقائق — ابدأ الآن';
        alert('👑 كفو يا محمد! كسرت التسويف، كمّل الحين!');return;
      }
      sparkSec--;
      const m=Math.floor(sparkSec/60),s=sparkSec%60;
      disp.textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    },1000);
  }
}

// ===== MISC =====
function toggleFullscreen(){
  if(!document.fullscreenElement)document.documentElement.requestFullscreen().catch(()=>{});
  else document.exitFullscreen().catch(()=>{});
}
function toast(msg){
  const t=document.getElementById('toast');t.textContent=msg;t.style.display='block';
  setTimeout(()=>t.style.display='none',3500);
}

// ===== CATEGORY TABS =====
function switchCat(cat){
  document.querySelectorAll('.sound-panel').forEach(p=>p.style.display='none');
  document.querySelectorAll('.mcat-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('panel-'+cat).style.display='block';
  document.getElementById('mcat-'+cat).classList.add('active');
}

// ===== SOUND ENGINE (Web Audio API) — 16 sounds =====
let audioCtx=null, currentNodes=[], masterGain=null, currentSound=null;
const soundNames={
  rain_light:'🌦️ مطر خفيف', rain_heavy:'⛈️ مطر غزير',
  rain_roof:'🏠 مطر على السطح', rain_storm:'🌩️ عاصفة رعدية',
  waves_gentle:'🌊 أمواج هادئة', waves_deep:'🌀 أمواج عميقة',
  stream:'🏞️ جدول ماء', underwater:'🐠 تحت الماء',
  wind_soft:'🍃 نسيم خفيف', wind_strong:'💨 ريح قوية',
  forest_birds:'🦜 غابة وطيور', campfire:'🔥 نار مخيم',
  lofi_chill:'🎵 Lo-Fi هادئ', lofi_beat:'🥁 Lo-Fi بيت',
  ambient:'🌌 أمبيانت', drone:'🎶 درون عميق'
};

function getAudioCtx(){
  if(!audioCtx){
    audioCtx=new(window.AudioContext||window.webkitAudioContext)();
    masterGain=audioCtx.createGain();
    masterGain.gain.value=parseFloat(document.getElementById('volSlider').value);
    masterGain.connect(audioCtx.destination);
  }
  return audioCtx;
}

function stopSound(){
  currentNodes.forEach(n=>{try{n.stop();}catch(e){}});
  currentNodes=[];
  currentSound=null;
  document.querySelectorAll('.music-btn').forEach(b=>{
    b.style.borderColor='';b.style.color='';b.style.background='';
  });
  document.getElementById('nowPlaying').style.display='none';
}

function playSound(type){
  const ctx=getAudioCtx();
  if(ctx.state==='suspended')ctx.resume();
  if(currentSound===type){stopSound();return;}
  stopSound();
  currentSound=type;
  const nodes=[];
  const t=ctx.currentTime;

  // ── helpers ──
  function pinkNoise(ch=2,sec=2){
    const buf=ctx.createBuffer(ch,sec*ctx.sampleRate,ctx.sampleRate);
    for(let c=0;c<ch;c++){
      const d=buf.getChannelData(c);
      let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0;
      for(let i=0;i<d.length;i++){
        const w=Math.random()*2-1;
        b0=.99886*b0+w*.0555179;b1=.99332*b1+w*.0750759;
        b2=.969*b2+w*.153852;b3=.8665*b3+w*.3104856;
        b4=.55*b4+w*.5329522;b5=-.7616*b5-w*.016898;
        d[i]=(b0+b1+b2+b3+b4+b5+w*.5362)*.11;
      }
    }
    return buf;
  }
  function whiteBuf(sec=2){
    const buf=ctx.createBuffer(1,sec*ctx.sampleRate,ctx.sampleRate);
    const d=buf.getChannelData(0);
    for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
    return buf;
  }
  function lpf(freq){const f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=freq;return f;}
  function hpf(freq){const f=ctx.createBiquadFilter();f.type='highpass';f.frequency.value=freq;return f;}
  function bpf(freq,q=1){const f=ctx.createBiquadFilter();f.type='bandpass';f.frequency.value=freq;f.Q.value=q;return f;}
  function gain(v){const g=ctx.createGain();g.gain.value=v;return g;}
  function src(buf,loop=true){const s=ctx.createBufferSource();s.buffer=buf;s.loop=loop;return s;}
  function osc(type,freq){const o=ctx.createOscillator();o.type=type;o.frequency.value=freq;return o;}

  // ── RAIN LIGHT ──
  if(type==='rain_light'){
    const s=src(pinkNoise());const f=lpf(900);const g=gain(0.18);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    function drop(){if(currentSound!==type)return;
      const o=osc('sine',600+Math.random()*300),g2=gain(0);
      g2.gain.setValueAtTime(0,ctx.currentTime);
      g2.gain.linearRampToValueAtTime(0.02,ctx.currentTime+0.01);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.1);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.12);
      setTimeout(drop,120+Math.random()*200);}
    drop();
  }
  // ── RAIN HEAVY ──
  else if(type==='rain_heavy'){
    const s=src(pinkNoise());const f=lpf(2000);const g=gain(0.45);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    function drop(){if(currentSound!==type)return;
      const o=osc('sine',500+Math.random()*600),g2=gain(0);
      g2.gain.linearRampToValueAtTime(0.05,ctx.currentTime+0.005);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.08);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.1);
      setTimeout(drop,20+Math.random()*60);}
    drop();
  }
  // ── RAIN ROOF ──
  else if(type==='rain_roof'){
    const s=src(pinkNoise());const f=hpf(800);const f2=lpf(3000);const g=gain(0.25);
    s.connect(f);f.connect(f2);f2.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    // metallic taps
    function tap(){if(currentSound!==type)return;
      const o=osc('triangle',2000+Math.random()*1000),g2=gain(0);
      g2.gain.linearRampToValueAtTime(0.03,ctx.currentTime+0.003);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.06);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.07);
      setTimeout(tap,30+Math.random()*100);}
    tap();
  }
  // ── RAIN STORM ──
  else if(type==='rain_storm'){
    const s=src(pinkNoise());const g=gain(0.5);s.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    // wind howl
    const wOsc=osc('sawtooth',80);const wG=gain(0.06);const wF=lpf(300);
    const lfo=osc('sine',0.2);const lfoG=gain(30);
    lfo.connect(lfoG);lfoG.connect(wF.frequency);
    wOsc.connect(wF);wF.connect(wG);wG.connect(masterGain);
    wOsc.start();lfo.start();nodes.push(wOsc,lfo);
    // thunder
    function thunder(){if(currentSound!==type)return;
      const nb=ctx.createBuffer(1,ctx.sampleRate*1.5,ctx.sampleRate);
      const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
      const ts=src(nb,false);const tf=lpf(200);const tg=gain(0);
      tg.gain.setValueAtTime(0,ctx.currentTime);
      tg.gain.linearRampToValueAtTime(0.8,ctx.currentTime+0.05);
      tg.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+1.4);
      ts.connect(tf);tf.connect(tg);tg.connect(masterGain);ts.start();
      setTimeout(thunder,4000+Math.random()*8000);}
    setTimeout(thunder,2000);
  }
  // ── WAVES GENTLE ──
  else if(type==='waves_gentle'){
    for(let w=0;w<3;w++){
      const s=src(whiteBuf(3));const f=bpf(200+w*100,0.8);const g=gain(0.1);
      const lfo=osc('sine',0.07+w*0.03);const lG=gain(0.08);
      lfo.connect(lG);lG.connect(g.gain);
      s.connect(f);f.connect(g);g.connect(masterGain);
      lfo.start();s.start(t+w*0.7);nodes.push(s,lfo);}
  }
  // ── WAVES DEEP ──
  else if(type==='waves_deep'){
    for(let w=0;w<4;w++){
      const s=src(pinkNoise(1,3));const f=lpf(400);const g=gain(0.15);
      const lfo=osc('sine',0.05+w*0.02);const lG=gain(0.12);
      lfo.connect(lG);lG.connect(g.gain);
      s.connect(f);f.connect(g);g.connect(masterGain);
      lfo.start();s.start(t+w*1.1);nodes.push(s,lfo);}
  }
  // ── STREAM ──
  else if(type==='stream'){
    const s=src(whiteBuf(3));const f=bpf(600,2);const g=gain(0.2);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    function bubble(){if(currentSound!==type)return;
      const o=osc('sine',400+Math.random()*800),g2=gain(0);
      g2.gain.linearRampToValueAtTime(0.025,ctx.currentTime+0.02);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.2);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.25);
      setTimeout(bubble,60+Math.random()*180);}
    bubble();
  }
  // ── UNDERWATER ──
  else if(type==='underwater'){
    const s=src(pinkNoise());const f=lpf(300);const g=gain(0.3);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    const chorus=osc('sine',60);const cG=gain(0.04);const cF=lpf(200);
    chorus.connect(cF);cF.connect(cG);cG.connect(masterGain);chorus.start();nodes.push(chorus);
    function bubble(){if(currentSound!==type)return;
      const o=osc('sine',200+Math.random()*300),g2=gain(0);
      o.frequency.linearRampToValueAtTime(o.frequency.value*1.5,ctx.currentTime+0.3);
      g2.gain.linearRampToValueAtTime(0.02,ctx.currentTime+0.05);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.35);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.4);
      setTimeout(bubble,300+Math.random()*800);}
    bubble();
  }
  // ── WIND SOFT ──
  else if(type==='wind_soft'){
    const s=src(pinkNoise());const f=lpf(500);const g=gain(0.2);
    const lfo=osc('sine',0.1);const lG=gain(0.1);
    lfo.connect(lG);lG.connect(g.gain);
    s.connect(f);f.connect(g);g.connect(masterGain);lfo.start();s.start();nodes.push(s,lfo);
    function leaf(){if(currentSound!==type)return;
      const o=osc('sine',800+Math.random()*400),g2=gain(0);
      g2.gain.linearRampToValueAtTime(0.01,ctx.currentTime+0.1);
      g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.4);
      o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.5);
      setTimeout(leaf,500+Math.random()*1500);}
    leaf();
  }
  // ── WIND STRONG ──
  else if(type==='wind_strong'){
    const s=src(pinkNoise());const f=bpf(300,0.5);const g=gain(0.4);
    const lfo=osc('sine',0.25);const lG=gain(0.25);
    lfo.connect(lG);lG.connect(g.gain);
    s.connect(f);f.connect(g);g.connect(masterGain);lfo.start();s.start();nodes.push(s,lfo);
    const howl=osc('sawtooth',100);const hF=lpf(250);const hG=gain(0.05);
    const hLfo=osc('sine',0.3);const hLG=gain(40);
    hLfo.connect(hLG);hLG.connect(hF.frequency);
    howl.connect(hF);hF.connect(hG);hG.connect(masterGain);howl.start();hLfo.start();
    nodes.push(howl,hLfo);
  }
  // ── FOREST BIRDS ──
  else if(type==='forest_birds'){
    const s=src(pinkNoise());const f=lpf(500);const g=gain(0.15);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
    function chirp(){if(currentSound!==type)return;
      const n=1+Math.floor(Math.random()*3);
      for(let i=0;i<n;i++){setTimeout(()=>{
        if(currentSound!==type)return;
        const freq=1200+Math.random()*2000;
        const o=osc('sine',freq),g2=gain(0);
        o.frequency.linearRampToValueAtTime(freq*(0.8+Math.random()*0.6),ctx.currentTime+0.08);
        g2.gain.linearRampToValueAtTime(0.05,ctx.currentTime+0.02);
        g2.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.18);
        o.connect(g2);g2.connect(masterGain);o.start();o.stop(ctx.currentTime+0.2);
      },i*180);}
      setTimeout(chirp,800+Math.random()*2500);}
    chirp();
  }
  // ── CAMPFIRE ──
  else if(type==='campfire'){
    const s=src(pinkNoise());const f=bpf(800,1.5);const g=gain(0.18);
    const lfo=osc('sine',8);const lG=gain(0.04);
    lfo.connect(lG);lG.connect(g.gain);
    s.connect(f);f.connect(g);g.connect(masterGain);lfo.start();s.start();nodes.push(s,lfo);
    function crackle(){if(currentSound!==type)return;
      const nb=ctx.createBuffer(1,Math.floor(ctx.sampleRate*0.03),ctx.sampleRate);
      const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()-0.5);
      const cs=src(nb,false);const cF=hpf(1500);const cG=gain(0.08+Math.random()*0.12);
      cs.connect(cF);cF.connect(cG);cG.connect(masterGain);cs.start();
      setTimeout(crackle,100+Math.random()*400);}
    crackle();
  }
  // ── LOFI CHILL ──
  else if(type==='lofi_chill'){
    const chords=[[261,329,392],[294,370,440],[349,440,523],[220,277,349]];
    let ci=0;
    function chord(){if(currentSound!==type)return;
      chords[ci++%4].forEach(fr=>{
        const o=osc('triangle',fr),g=gain(0);
        g.gain.linearRampToValueAtTime(0.035,ctx.currentTime+0.4);
        g.gain.setValueAtTime(0.035,ctx.currentTime+1.8);
        g.gain.linearRampToValueAtTime(0,ctx.currentTime+2.4);
        o.connect(g);g.connect(masterGain);o.start();o.stop(ctx.currentTime+2.6);});
      setTimeout(chord,2500);}
    chord();
    function crackle(){if(currentSound!==type)return;
      const nb=ctx.createBuffer(1,Math.floor(ctx.sampleRate*.04),ctx.sampleRate);
      const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()-.5)*.25;
      const cs=src(nb,false);const f=hpf(2500);const g=gain(0.012);
      cs.connect(f);f.connect(g);g.connect(masterGain);cs.start();
      setTimeout(crackle,80+Math.random()*220);}
    crackle();
  }
  // ── LOFI BEAT ──
  else if(type==='lofi_beat'){
    const chords=[[196,247,294],[220,277,330],[175,220,262],[247,311,370]];
    let ci=0;
    function chord(){if(currentSound!==type)return;
      chords[ci++%4].forEach(fr=>{
        const o=osc('triangle',fr),g=gain(0);
        g.gain.linearRampToValueAtTime(0.03,ctx.currentTime+0.2);
        g.gain.linearRampToValueAtTime(0,ctx.currentTime+1.8);
        o.connect(g);g.connect(masterGain);o.start();o.stop(ctx.currentTime+2);});
      setTimeout(chord,2000);}
    chord();
    function kick(){if(currentSound!==type)return;
      const o=osc('sine',120),g=gain(0.15);
      o.frequency.exponentialRampToValueAtTime(40,ctx.currentTime+0.1);
      g.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.15);
      o.connect(g);g.connect(masterGain);o.start();o.stop(ctx.currentTime+0.18);
      setTimeout(kick,480);}
    kick();
    function hihat(){if(currentSound!==type)return;
      const nb=ctx.createBuffer(1,Math.floor(ctx.sampleRate*.02),ctx.sampleRate);
      const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
      const s=src(nb,false);const f=hpf(8000);const g=gain(0.04);
      s.connect(f);f.connect(g);g.connect(masterGain);s.start();
      setTimeout(hihat,240);}
    hihat();
    function crackle(){if(currentSound!==type)return;
      const nb=ctx.createBuffer(1,Math.floor(ctx.sampleRate*.04),ctx.sampleRate);
      const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()-.5)*.2;
      const cs=src(nb,false);const f=hpf(2500);const g=gain(0.01);
      cs.connect(f);f.connect(g);g.connect(masterGain);cs.start();
      setTimeout(crackle,60+Math.random()*160);}
    crackle();
  }
  // ── AMBIENT ──
  else if(type==='ambient'){
    [[80,0.05],[160,0.04],[320,0.03],[640,0.025]].forEach(([fr,vol],i)=>{
      const o=osc('sine',fr),g=gain(vol);
      const lfo=osc('sine',0.03+i*0.01);const lG=gain(vol*0.4);
      lfo.connect(lG);lG.connect(g.gain);
      o.connect(g);g.connect(masterGain);o.start();lfo.start();nodes.push(o,lfo);});
    const s=src(pinkNoise());const f=lpf(200);const g=gain(0.04);
    s.connect(f);f.connect(g);g.connect(masterGain);s.start();nodes.push(s);
  }
  // ── DRONE ──
  else if(type==='drone'){
    [55,110,165,220].forEach((fr,i)=>{
      const o=osc(i%2===0?'sine':'triangle',fr),g=gain(0.06);
      const lfo=osc('sine',0.05+i*0.015);const lG=gain(0.03);
      lfo.connect(lG);lG.connect(g.gain);
      o.connect(g);g.connect(masterGain);o.start();lfo.start();nodes.push(o,lfo);});
  }

  currentNodes=nodes;
  document.querySelectorAll('.music-btn').forEach(b=>{b.style.borderColor='';b.style.color='';b.style.background='';});
  const btn=document.getElementById('mbtn-'+type);
  if(btn){btn.style.borderColor='var(--gold2)';btn.style.color='var(--gold2)';btn.style.background='rgba(212,160,23,0.12)';}
  const np=document.getElementById('nowPlaying');
  document.getElementById('nowPlayingText').textContent=(soundNames[type]||type)+' — يعزف الآن';
  np.style.display='block';
}

function setVolume(v){
  if(masterGain)masterGain.gain.value=parseFloat(v);
  document.getElementById('volLabel').textContent=Math.round(v*100)+'%';
}